package usecase

import (
	"context"
	"fmt"
	"io"
	"main/model"
	"main/repository"
	"net/http"

	"go.mongodb.org/mongo-driver/bson"
)

type StationUsecase struct {
	repository repository.StationRepository
}

func NewStationUseCase(repo repository.StationRepository) StationUsecase {
	return StationUsecase{
		repository: repo,
	}
}

func (su *StationUsecase) CreateStation(station model.Station) (model.Station, error) {

	id, err := su.repository.CreateStation(station)
	if err != nil {
		return model.Station{}, err
	}
	station.StationID = id

	return station, nil
}
func (su *StationUsecase) GetAllStations(ctx context.Context, company string) ([]model.Station, error) {
	stations, err := su.repository.GetAllStations(ctx, company)
	if err != nil {
		return nil, err
	}
	return stations, nil
}

func (su *StationUsecase) GetStationFromExternalServer(url string) ([]model.Station, error) {
	// Faz a requisição HTTP
	resp, err := http.Get(url)
	if err != nil {
		return nil, fmt.Errorf("erro ao fazer requisição para o Servidor 2: %w", err)
	}
	defer resp.Body.Close()

	// Lê o corpo da resposta
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("erro ao ler resposta do Servidor 2: %w", err)
	}

	// Agora, queremos deserializar o BSON. Caso o retorno seja um array direto ou um documento com a chave "stations".
	var stations []model.Station

	// Tente deserializar como BSON
	if err := bson.Unmarshal(body, &stations); err != nil {
		// Se falhar, tenta deserializar para um objeto com "stations"
		var response struct {
			Stations []model.Station `bson:"stations"`
		}
		if err := bson.Unmarshal(body, &response); err != nil {
			return nil, fmt.Errorf("erro ao deserializar a resposta do servidor 2: %w", err)
		}
		stations = response.Stations
	}

	return stations, nil
}
