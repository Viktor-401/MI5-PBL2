package types

// const BROKER = "mqtt.eclipseprojects.io"
// const BROKER = "localhost"
const BROKER = "172.16.103.9"
const PORT = 1885
