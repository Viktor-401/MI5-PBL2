package types

// const BROKER = "mqtt.eclipseprojects.io"
// const BROKER = "localhost"
const BROKER = "172.16.201.10" // ip da máquina que possui o broker
const PORT = 1885          //porta da maquina que possui o proker
