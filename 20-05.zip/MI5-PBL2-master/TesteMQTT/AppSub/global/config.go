package global

// const BROKER = "mqtt.eclipseprojects.io"
const BROKER = "mosquitto"
const PORT = 1883
